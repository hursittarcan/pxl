# Mastermind

Startcode of the Mastermind project (1TIN, 2018-2019)

You yan find more info in the [Wiki](https://bitbucket.org/Lecturers1TINProject/mastermind-backend/wiki)