﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using MasterMind.Data.DomainClasses;

namespace MasterMind.Data.Repositories
{
    public class InMemoryWaitingRoomRepository : IWaitingRoomRepository
    {
        private ConcurrentDictionary<Guid, WaitingRoom> waitingRooms;

        public InMemoryWaitingRoomRepository()
        {
            waitingRooms = new ConcurrentDictionary<Guid, WaitingRoom>();
        }

        public WaitingRoom Add(WaitingRoom newWaitingRoom)
        {
            newWaitingRoom.Id = Guid.NewGuid();
            waitingRooms.TryAdd(newWaitingRoom.Id, newWaitingRoom);
            return newWaitingRoom;
            //TODO
            //throw new NotImplementedException();
        }

        public WaitingRoom GetById(Guid id)
        {
            bool bestaatWachtkamerBool = waitingRooms.TryGetValue(id, out WaitingRoom value);
            if (value == null)
            {
                throw new DataNotFoundException();
            }
            return value;
            //TODO
            //throw new NotImplementedException();
        }

        public ICollection<WaitingRoom> GetAll()
        {
            return waitingRooms.Values;

            //TODO
            //throw new NotImplementedException();
        }

        public void DeleteById(Guid id)
        {
            waitingRooms.Remove(id, out WaitingRoom value);
        }
    }
}