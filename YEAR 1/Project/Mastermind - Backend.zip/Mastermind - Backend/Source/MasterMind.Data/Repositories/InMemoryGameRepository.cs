﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using MasterMind.Data.DomainClasses;

namespace MasterMind.Data.Repositories
{
    public class InMemoryGameRepository : IGameRepository
    {
        private ConcurrentDictionary<Guid, IGame> game;

        public InMemoryGameRepository()
        {
            game = new ConcurrentDictionary<Guid, IGame>();
        }

        public IGame Add(IGame newGame)
        {
            newGame.Id = Guid.NewGuid();
            game.TryAdd(newGame.Id, newGame);
            return newGame;
            //throw new NotImplementedException();
        }

        public IGame GetById(Guid id)
        {
            bool bestaatGameBool = game.TryGetValue(id, out IGame value);
            if (value == null)
            {
                throw new DataNotFoundException();
            }
            return value;
            //throw new NotImplementedException();
        }

        public void DeleteById(Guid id)
        {
            game.TryRemove(id, out IGame value);
            //throw new NotImplementedException();
        }
    }
}