﻿using System.Collections.Generic;
using System.Linq;

namespace MasterMind.Data.DomainClasses
{
    public class GuessResult
    {
        private int _correctColorAndPositionAmount;
        private int _correctColorAmount;

        public string[] Colors { get; set; }

        public virtual int CorrectColorAndPositionAmount => _correctColorAndPositionAmount; //must be virtual for some automated test to work!

        public virtual int CorrectColorAmount => _correctColorAmount; //must be virtual for some automated test to work!

        public GuessResult(string[] colors)
        {
           
            Colors = colors;

           
            
        }



        public void Verify(string[] codeToGuess)        //hier controleren of de gok juist is aan colors
        {
            List<string> colorsToGuess = new List<string>(codeToGuess);        //uw gok

     




            List<string> rightColors = new List<string>(Colors);          //juiste kleurcode

    


            int correctColorAndPos = 0;     //var voor tellen correctcolorandplosition
            IList<string> toRemove = new List<string>();
            for (int i = 0; i < Colors.Length; i++)
            {
                if (Colors[i].Equals(codeToGuess[i]))
                {
                    //optellen juiste kleur en positie
                    correctColorAndPos++;
                    toRemove.Add(Colors[i]);
                }
            }

            _correctColorAndPositionAmount = correctColorAndPos;


            for (int i = 0; i < toRemove.Count; i++)
            {
                rightColors.Remove(toRemove[i]);
                colorsToGuess.Remove(toRemove[i]);
            }
         


            int correctColors = 0;          //var voor tellen correctcoloramount

            for (int i = 0; i < colorsToGuess.Count; i++)
            {
                //tellen hoeveel kleuren niet op de juiste plaats staan 
                if (rightColors.Contains(colorsToGuess[i]))
                {
                    
                    
                    rightColors.Remove(colorsToGuess[i]);
                    correctColors++;
                }
            }

            _correctColorAmount = correctColors;

        }
    }
}