﻿namespace MasterMind.Data.DomainClasses
{
    public enum GameMode
    {
        Default = 1,
        Fast = 2,
        Smart = 3,
        Stress = 4
    }
}