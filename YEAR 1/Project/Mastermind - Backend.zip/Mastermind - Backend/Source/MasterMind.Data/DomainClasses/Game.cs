﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MasterMind.Data.DomainClasses
{
    public class Game : IGame
    {
        private int _currentRound;

        public Guid Id { get; set; }
        public GameSettings Settings { get; set; }
        public IList<IPlayer> Players { get; }
        public string[] PossibleColors { get; }
        public int CurrentRound => _currentRound;
        private string[] allColors = new string[] { "blue", "red", "yellow", "green", "orangered", "purple", "black", "white" };


    private string[] _codeToGuess;
        public Dictionary<Guid, Int32> numberOfGuesses = new Dictionary<Guid,Int32>();

        /// <summary>
        /// Constructs a Game object and generates a code to guess.
        /// </summary>
        public Game(GameSettings settings, IList<IPlayer> players)
        {
            PossibleColors = new string[settings.AmountOfColors];
            for (int i = 0; i < PossibleColors.Length; i++)
            {
                PossibleColors[i] = allColors[i];
            }
            _codeToGuess = new string[settings.CodeLength];
            Settings = settings;
            Players = players;
            int[] combinatie = new int[settings.CodeLength];
            

            if (!settings.DuplicateColorsAllowed)
            {
                for (int i = 0; i < settings.CodeLength; i++)
                {
                    while (combinatie[i] == 0)
                    {
                        Random random = new Random();
                        int random2 = random.Next(1, PossibleColors.Length + 1);
                        if (!combinatie.Contains(random2))
                        {
                            combinatie[i] = Convert.ToInt32(random2);
                        }
                    }
                }
                for (int i = 0; i < settings.CodeLength; i++)
                {
                    _codeToGuess[i] = Convert.ToString(PossibleColors.GetValue(combinatie[i] - 1));
                }

                _currentRound = 1;

            }
            
             //TODO
        }

        public CanGuessResult CanGuessCode(IPlayer player, int roundNumber)
        {
           /* if(Settings.MaximumAmountOfGuesses = numberOfGuesses)
            {
                CanGuessCode = MaximumReached;
            }*/
            //TODO
            throw new NotImplementedException();
        }

        public GuessResult GuessCode(string[] colors, IPlayer player)
        {
           // numberOfGuesses++;
            throw new NotImplementedException();
        }

        public GameStatus GetStatus()
        {
            //TODO
            throw new NotImplementedException();
        }
    }
}