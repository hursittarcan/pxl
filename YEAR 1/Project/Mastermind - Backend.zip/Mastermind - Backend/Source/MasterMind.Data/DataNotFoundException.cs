﻿using System;

namespace MasterMind.Data
{
    public class DataNotFoundException : ApplicationException
    {
    }
}
