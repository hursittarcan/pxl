﻿namespace MasterMind.Api.Models
{
    public class GuessModel
    {
        public string[] Colors { get; set; }
    }
}