﻿using System;

namespace MasterMind.Api.Models
{
    public class PlayerModel
    {
        public Guid Id { get; set; }
        public string NickName { get; set; }
    }
}