﻿namespace MasterMind.Api.Models
{
    public class AccessPassModel
    {
        public PlayerModel Player { get; set; }
        public string Token { get; set; }
    }
}