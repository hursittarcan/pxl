﻿using System;
using MasterMind.Business.Models;
using MasterMind.Data.DomainClasses;
using MasterMind.Data.Repositories;
using System.Collections.Generic;
using System.Linq;
using MasterMind.Data;

namespace MasterMind.Business.Services
{
    public class WaitingRoomService : IWaitingRoomService
    {
        private IWaitingRoomRepository _repo;

        public WaitingRoomService(IWaitingRoomRepository waitingRoomRepository)
        {
            _repo = waitingRoomRepository;
            //TODO
        }

        public ICollection<WaitingRoom> GetAllAvailableRooms()
        {
            ICollection<WaitingRoom> allWaitingRooms = _repo.GetAll();
            ICollection<WaitingRoom> availableWaitingRooms = new List<WaitingRoom>();
            foreach (WaitingRoom waitingRoom in allWaitingRooms)
            {
                if (waitingRoom.MaximumAmountOfUsers != waitingRoom.Users.Count)
                {
                    availableWaitingRooms.Add(waitingRoom);
                }
            }

            return availableWaitingRooms;
            //TODO
        }

        public WaitingRoom CreateRoom(WaitingRoomCreationModel roomToCreate, User creator)
        {
            int teller = 0;
            WaitingRoom createdWaitingRoom;
            foreach (WaitingRoom waitingRoom in _repo.GetAll())
            {
                if (roomToCreate.Name == waitingRoom.Name)
                {
                    teller++;
                    throw new ApplicationException();
                }
            }
            if (teller == 0)
            {
                createdWaitingRoom = new WaitingRoom(roomToCreate.Name, creator, roomToCreate.GameSettings);
                _repo.Add(createdWaitingRoom);
                return createdWaitingRoom;
            }
            else
            {
                return null;
            }

            //TODO
            //throw new NotImplementedException();
        }

        public WaitingRoom GetRoomById(Guid id)
        {
            WaitingRoom existingWaitingRoom = _repo.GetById(id);

            if (existingWaitingRoom == null)
            {
                throw new DataNotFoundException();
            }
            return existingWaitingRoom;
            //TODO
        }

        public bool TryJoinRoom(Guid roomId, User user, out string failureReason)
        {
            try
            {
                WaitingRoom currentWaitingRoom = _repo.GetById(roomId);

                if (currentWaitingRoom.Users.Count() == currentWaitingRoom.MaximumAmountOfUsers)
                {
                    failureReason = "Waiting room is already at maximum capacity";
                    return false;
                }
                if (currentWaitingRoom.Users.Contains(user))
                {
                    failureReason = "Player is already in this lobby";
                    return false;
                }
                failureReason = "";
                currentWaitingRoom.Users.Add(user);
                return true;
            }
            catch (DataNotFoundException)
            {
                failureReason = "Waiting room with this id does not exist";
                return false;
            }
            //TODO
        }

        public bool TryLeaveRoom(Guid roomId, User user, out string failureReason)
        {
            try
            {
                WaitingRoom currentWaitingRoom = _repo.GetById(roomId);

                if (!currentWaitingRoom.Users.Contains(user))
                {
                    failureReason = "Player is not in this lobby";
                    return false;
                }
                currentWaitingRoom.Users.Remove(user);

                if (user.Id == currentWaitingRoom.CreatorUserId)
                {
                    _repo.DeleteById(currentWaitingRoom.Id);
                }
                failureReason = "";
                return true;
            }
            catch (DataNotFoundException)
            {
                failureReason = "Waiting room with this id does not exist";
                return false;
            }





            //TODO
        }
    }
}