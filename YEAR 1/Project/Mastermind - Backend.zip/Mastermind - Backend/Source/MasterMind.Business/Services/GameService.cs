﻿using MasterMind.Data.DomainClasses;
using System;
using System.Linq;
using MasterMind.Data.Repositories;

namespace MasterMind.Business.Services
{
    public class GameService : IGameService
    {
        private IWaitingRoomService _waitingRoomService;
        private IGameRepository _gameRepository;

        public GameService(IWaitingRoomService waitingRoomService, IGameRepository gameRepository)
        {
            _waitingRoomService = waitingRoomService;
            _gameRepository = gameRepository; 
        }

        public IGame StartGameForRoom(Guid roomId)
        {
            WaitingRoom waitingroom = _waitingRoomService.GetRoomById(roomId);
            if (waitingroom.Users.Count < 2)
            {

                throw new ApplicationException();

            }




            //TODO
            throw new NotImplementedException();
        }

        public IGame GetGameById(Guid id)
        {

            return _gameRepository.GetById(id);
        }

        public CanGuessResult CanGuessCode(Guid gameId, IPlayer player, int roundNumber)
        {
            CanGuessResult result =_gameRepository.GetById(gameId).CanGuessCode(player, roundNumber);
            if (result != CanGuessResult.Ok)
            {

                throw new ApplicationException();

            }

            return result;
                        
        }

        public GuessResult GuessCode(Guid gameId, string[] colors, IPlayer player)
        {
            IGame game = _gameRepository.GetById(gameId);
            game.CanGuessCode(player, game.CurrentRound);

            // nog verder werken, geen guessresult maar een canguessresult van maken
           
       }

        public GameStatus GetGameStatus(Guid gameId)
        {
            return _gameRepository.GetById(gameId).GetStatus();
        }
    }
}