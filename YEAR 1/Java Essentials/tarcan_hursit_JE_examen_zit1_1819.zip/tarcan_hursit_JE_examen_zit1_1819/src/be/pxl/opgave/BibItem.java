package be.pxl.opgave;

public abstract class BibItem implements Uitleenbaar {
    private static final int MAX_TERMIJN = 15;
    private static final int MIN_LEEFTIJD_STANDAARD = 10;
    private String titel;
    private Auteur auteur;
    private int uitgifteJaar;
    private int minimumLeeftijd;

    public BibItem(String titel, Auteur auteur, int uitgifteJaar) {
        this.titel = titel;
        this.auteur = auteur;
        this.uitgifteJaar = uitgifteJaar;
    }

    public String getTitel() {
        return titel;
    }

    public void setTitel(String titel) {
        this.titel = titel;
    }

    public Auteur getAuteur() {
        return auteur;
    }

    public void setAuteur(Auteur auteur) {
        this.auteur = auteur;
    }

    public int getUitgifteJaar() {
        return uitgifteJaar;
    }

    public void setUitgifteJaar(int uitgifteJaar) {
        this.uitgifteJaar = uitgifteJaar;
    }

    public int getMinimumLeeftijd() {
        return minimumLeeftijd;
    }

    public void setMinimumLeeftijd(int minimumLeeftijd) {
        minimumLeeftijd = MIN_LEEFTIJD_STANDAARD;
        this.minimumLeeftijd = minimumLeeftijd;
    }

    public static int getMaxTermijn() {
        return MAX_TERMIJN;
    }

    @Override
    public String toString() {
        String tekst = String.format("%s, %s, %d", auteur, titel, uitgifteJaar);
        return tekst;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BibItem bibItem = (BibItem) o;

        if (uitgifteJaar != bibItem.uitgifteJaar) return false;
        if (minimumLeeftijd != bibItem.minimumLeeftijd) return false;
        if (titel != null ? !titel.equals(bibItem.titel) : bibItem.titel != null) return false;
        return auteur != null ? auteur.equals(bibItem.auteur) : bibItem.auteur == null;
    }

    @Override
    public int hashCode() {
        int result = titel != null ? titel.hashCode() : 0;
        result = 31 * result + (auteur != null ? auteur.hashCode() : 0);
        result = 31 * result + uitgifteJaar;
        result = 31 * result + minimumLeeftijd;
        return result;
    }
}
