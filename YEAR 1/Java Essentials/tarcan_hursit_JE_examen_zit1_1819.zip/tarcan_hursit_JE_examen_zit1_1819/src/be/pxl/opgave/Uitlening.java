package be.pxl.opgave;

import java.time.LocalDate;

public class Uitlening {
    private LocalDate uitleenDatum;
    private BibItem bibItem;
    private Lezer lezer;

    public Uitlening(BibItem bibItem, Lezer lerer, LocalDate uitleenDatum) {
        this.bibItem = bibItem;
        this.lezer = lerer;
        this.uitleenDatum = uitleenDatum;
    }

    public LocalDate getUitleenDatum() {
        return uitleenDatum;
    }

    public void setUitleenDatum(LocalDate uitleenDatum) {
        this.uitleenDatum = uitleenDatum;
    }

    public BibItem getBibItem() {
        return bibItem;
    }

    public void setBibItem(BibItem bibItem) {
        this.bibItem = bibItem;
    }

    public Lezer getLezer() {
        return lezer;
    }

    public void setLezer(Lezer lezer) {
        this.lezer = lezer;
    }

    public boolean isOverTijd(LocalDate datum) {
        return false;
    }

    public boolean isToegestaan() {
        if (bibItem.magUitlenen(getLezer())) {
            return true;
        }
        else {
            return false;
        }
    }

    public double getKostPrijs(LocalDate datum) {
        double kostprijs = 0;
        if (isOverTijd(datum) == false) {
            kostprijs = 0;
        }
        else if (isOverTijd(datum) == true) {
            if (2 > 1) // Wist niet hoe je checkt of het boek is of film is.
                kostprijs = kostprijs + 1.5 * 1; // 1 = weken over tijd, wist niet hoe je het berekende.)
            else {
                kostprijs = kostprijs + 0.75 * 1;
            }
        }
        return kostprijs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Uitlening uitlening = (Uitlening) o;

        return bibItem != null ? bibItem.equals(uitlening.bibItem) : uitlening.bibItem == null;
    }

    @Override
    public int hashCode() {
        return bibItem != null ? bibItem.hashCode() : 0;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
