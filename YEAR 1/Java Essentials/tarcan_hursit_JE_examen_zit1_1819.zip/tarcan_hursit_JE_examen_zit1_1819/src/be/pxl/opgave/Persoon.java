package be.pxl.opgave;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public abstract class Persoon {
    private String naam;
    private LocalDate geboortedatum;

    public Persoon(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public LocalDate getGeboortedatum() {
        return geboortedatum;
    }

    public void setGeboortedatum(LocalDate geboortedatum) {
        this.geboortedatum = geboortedatum;
    }

    public int getLeeftijd() {
        long leeftijd = ChronoUnit.YEARS.between(geboortedatum, LocalDate.now());
        return (int) leeftijd;
    }

    public String geefInitialen() {
        int plaatsSpatie = naam.indexOf(" ");
        String eersteLetter = naam.substring(0, 1).toUpperCase();
        String tweedeletter = naam.substring(plaatsSpatie, plaatsSpatie + 1).toUpperCase();
        return eersteLetter + tweedeletter;
    }

    @Override
    public String toString() {
        return naam;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Persoon persoon = (Persoon) o;

        if (naam != null ? !naam.equals(persoon.naam) : persoon.naam != null) return false;
        return geboortedatum != null ? geboortedatum.equals(persoon.geboortedatum) : persoon.geboortedatum == null;
    }

    @Override
    public int hashCode() {
        int result = naam != null ? naam.hashCode() : 0;
        result = 31 * result + (geboortedatum != null ? geboortedatum.hashCode() : 0);
        return result;
    }
}
