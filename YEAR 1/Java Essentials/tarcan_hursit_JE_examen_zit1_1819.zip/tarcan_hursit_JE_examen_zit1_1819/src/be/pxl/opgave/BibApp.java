//Tarcan Hursit
package be.pxl.opgave;

import java.time.LocalDate;

public class BibApp {

    public static void main(String[] args) {

        Boek b1 = new Boek("Vijftig tinten grijs", new Auteur("Erika James"), 2012, Genre.ROMAN);
        Boek b2 = new Boek("It", new Auteur("Stephen King"), 2012, Genre.THRILLER);
        Boek b3 = new Boek("Mijn pure keuken", new Auteur("Pascale Naessens"), 2011, Genre.KOKEN);

        FilmMuziek film = new FilmMuziek("Inception", new Auteur("Christopher Nolan"), 2010, "Film");
        FilmMuziek muziek = new FilmMuziek("Untitled unmastered", new Auteur("Kendrick Lamar"), 2016, "muziek");

        Lezer an = new Lezer("An Jansen");
        Lezer piet = new Lezer("Piet Peters");
        Lezer jantje = new Lezer("Jantje Vanopdenhoek");

        an.setGeboortedatum(LocalDate.of(1981, 3, 15));
        piet.setGeboortedatum(LocalDate.of(1973, 9, 11));
        jantje.setGeboortedatum(LocalDate.of(2012, 1, 10));
        film.setMinimumLeeftijd(16);

        Bib bibPXL = new Bib("Bib PXL");

        Uitlening[] u = new Uitlening[6];
        u[0] = new Uitlening(film, jantje, LocalDate.of(2019, 1, 6));
        u[1] = new Uitlening(muziek, an, LocalDate.of(2019, 1, 6));
        u[2] = new Uitlening(b1, an, LocalDate.of(2019, 1, 6));
        u[3] = new Uitlening(b2, piet, LocalDate.of(2019, 1, 6));
        u[4] = new Uitlening(b3, piet, LocalDate.of(2019, 1, 6));
        u[5] = new Uitlening(film, an, LocalDate.of(2019, 1, 6));

        for (int i = 0; i < 3; i++) {
            bibPXL.voegUitleningToe(u[i]);
        }

        System.out.println("---------");

        bibPXL.brengTerug(u[1], LocalDate.of(2019, 1, 24));

        for (int i = 3; i < 6; i++) {
            bibPXL.voegUitleningToe(u[i]);
        }

        System.out.println("---------");

        System.out.println("Lijst met de registraties in " + bibPXL.getNaam());
        for (Uitlening uitlening : bibPXL.getUitleningen()) {
            if (uitlening != null) {
                System.out.println(uitlening);
            }
        }

        System.out.println("---------");

        System.out.println(bibPXL.zoekOverTijd(LocalDate.of(2019, 2, 6)));
    }
}
