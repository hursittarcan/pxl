package be.pxl.opgave;

public enum Genre {
    ROMAN("RO"),
    DETECTIVE("D"),
    THRILLER("T"),
    SCIENCEFICTION("SF"),
    HUMOR("H"),
    KOKEN("K"),
    REIZEN("RE");

    private String afkorting;

    Genre() {
        String eersteLetter = afkorting.substring(0, 1);
    }

    Genre(String genre) {
        if (afkorting.length() > 1) {
            String totaal = afkorting.substring(0, 2);
        }
        else {
            String totaal = afkorting.substring(0, 1);
        }
    }

    @Override
    public String toString() {
        return super.toString();
    }
}


