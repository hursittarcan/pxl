package be.pxl.opgave;

public interface Uitleenbaar {
    abstract String getIdNummer();
    abstract boolean magUitlenen(Persoon uitlener);
}
