package be.pxl.opgave;

import java.time.LocalDate;
import java.util.ArrayList;

public class Bib {
    private String naam;
    private ArrayList<Uitlening> uitleningen;

    public Bib(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public ArrayList<Uitlening> getUitleningen() {
        return uitleningen;
    }

    public void voegUitleningToe(Uitlening uitlening) {
        if (uitleningen.contains(uitlening)) {
            System.out.println("De uitlening van dit item is al geregistreerd.");
        }
        else {
            uitleningen.add(uitlening);
            System.out.println("Ontlenen van item is gelukt.");
        }
    }

    public void brengTerug(Uitlening uitlening, LocalDate inleverDatum) {
        if (uitleningen.contains(uitlening)) {
            uitleningen.remove(uitlening);
            System.out.println("Het terugbrengen is gelukt");
        }
        else {
            System.out.println("ERROR, uitlening niet gevonden.");
        }
    }

    public String zoekOverTijd(LocalDate localDate) {
        return "";
    }
}
