package be.pxl.opgave;

public class Boek extends BibItem{
    private Genre genre;

    public Boek(String titel, Auteur auteur, int uitgifteJaar, Genre genre) {
        super(titel, auteur, uitgifteJaar);
        this.genre = genre;
    }

    @Override
    public String getIdNummer() {
        return String.format("%s%s%s", genre, getUitgifteJaar(), getAuteur().geefInitialen());
    }

    @Override
    public boolean magUitlenen(Persoon uitlener) {
        return true;
    }

    @Override
    public String toString() {
        String tekst = String.format("Boek: %s,", getIdNummer()) + super.toString();
        return tekst;
    }
}
