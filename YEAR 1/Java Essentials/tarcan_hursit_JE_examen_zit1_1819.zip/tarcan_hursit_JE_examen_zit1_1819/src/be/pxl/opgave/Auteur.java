package be.pxl.opgave;

public final class Auteur extends Persoon {
    public Auteur(String naam) {
        super(naam);
    }
}
