package be.pxl.opgave;

public class FilmMuziek extends BibItem {
    private String type;

    public FilmMuziek(String titel, Auteur auteur, int uitgifteJaar, String type) {
        super(titel, auteur, uitgifteJaar);
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        type = type.toUpperCase();
        this.type = type;
    }

    @Override
    public String getIdNummer() {
        if (type.equals("FILM")) {
            return String.format("F%d%s", getUitgifteJaar(), getAuteur().geefInitialen());
        }
        else {
            return String.format("M%d%S", getUitgifteJaar(), getAuteur().geefInitialen());
        }
    }

    @Override
    public boolean magUitlenen(Persoon uitlener) {
        if (uitlener.getLeeftijd() < getMinimumLeeftijd()) {
            return false;
        }
        else {
            return true;
        }
    }

    @Override
    public String toString() {
        return getIdNummer() + super.toString();
    }
}
