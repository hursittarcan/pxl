package be.pxl.opgave;

public final class Lezer extends Persoon{
    public Lezer(String naam) {
        super(naam);
    }
}
