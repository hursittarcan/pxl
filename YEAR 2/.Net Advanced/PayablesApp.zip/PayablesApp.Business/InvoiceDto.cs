﻿namespace PayablesApp.Business
{
    public class InvoiceDto
    {
        public string VendorName { get; set; }
        public string InvoiceNumber { get; set; }
        public decimal InvoiceTotal { get; set; }
    }
}
